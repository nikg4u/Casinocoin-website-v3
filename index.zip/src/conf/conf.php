<?php
/**
 * Created by PhpStorm.
 * User: kepoly
 * Date: 2/24/2016
 * Time: 7:09 PM
 */

define("WEBSITE_PATH", "http://localhost/personal/casinocoin/");
?>