<br />
<iframe src="https://casinocoin-slack.herokuapp.com/" width="100%" height="500px"></iframe>
