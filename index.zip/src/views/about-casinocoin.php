<div class="container otherPages">

<section class="about">

    <h1>Casinocoin Background Information</h1>

    <p>Since April 15th, 2011, a day dubbed as 'Black Friday' by the online gaming community, it has become increasingly difficult to deposit funds for online casino gaming due to deposit restrictions between centralized financial institutions and online casino platforms. Avid online players have since not been able to enjoy the same conveniences and the ease of accessibility that they were once afforded. Those days are no more with the advent of Casinocoin.
</p>
       <p> As a decentralized currency, Casinocoin offers the solution to help fill this void. Consider Casinocoin as a universal casino chip that is easily transferable between online casino gaming applications, exchanges and peers. Imagine using Casinocoin at your favorite online poker sites, then instantly transfer your winnings over to your favorite online casino to play Blackjack or sportsbook. How about a friendly wager over a game of chess or pool? This is all possible with Casinocoin.
</p>
     <p>   Alone, Casinocoin has no value. Within casino gaming applications, it can be used to play games of skill and chance. On the exchanges, Casinocoin is worth what the market values it at and it can be bought, sold and exchanged to fiat currencies such as US dollars or exchanged to other crypto currencies such as Bitcoin Thus giving it a value through adoption + use.
        Casinocoin is based on the strengths of crypto currency protocols such as Bitcoin, Litecoin, Feathercoin, digitalcoin, and digicoin giving it a second movers advantage. It leverages the security of Bitcoin, the accessibility of Litecoin, the abundance of Feathercoin, and the speed of digitalcoin as well encompassing the innovations of digicoin. While Casinocoin can be used as a general purpose currency, it serves a specific purpose and is marketed exclusively for online casino gaming and rewards redemption.
    </p>
    <h1>CSC - Two Brands one Blockchain</h1>
    <h2 class="text-csc">Casinocoin</h2>
    <h3>July 18, 2013 - Introducing Casinocoin: An open source, peer-to-peer digital currency specifically designed for online casino gaming.</h3>
    <p>Casinocoin is an open source, peer-to-peer digital currency specifically designed for online casino gaming. It's a platform independent currency that is easily transferable between gaming applications, exchanges and peers. Casinocoin can simply be summed up as universal casino chips.</p>
    <p>Central to the goal of Casinocoin is to help make online casino gaming accessible to all by removing barriers. The success and strength of Casinocoin rely on three main pillars: active and talented developers, fostering community, and trust through transparency.</p>
    <a href="https://github.com/Casinocoin/Casinocoin" target="_blank">Click Here to View the Casinocoin Source Code</a>
    <h2 class="text-csc">Caribbean Sandcoins</h2>
    <h3>February 02, 2016 - Introducing Sandcoins: An Alternatively Branded Casinocoin Wallet</h3>
    <h4>The Casinocoin Foundation is proud to announce the release of an alternatively branded Casinocoin wallet named: </h4>
    <h4>Caribbean Sandcoins.</h4>
    <p>This version of the wallet is being released at the request of merchant services who desired to utilize Casinocoins for an ecommerce/merchant application in a major Caribbean country outside the Bahamas. The main issue at hand was that the current gambling-branded wallet would not have been compliant with existing banking regulation in this particular country. In negotiation with this partner, the "Caribbean Sandcoin" name was chosen because it was considered generic, tropical themed, and conformed to the CSC designation. </p>
    <a href="https://github.com/SandCoins/sandcoin-wallet" target="_blank">Click Here to View the Sandcoins Source Code</a>
    <h3 class="text-center">How does this work?</h3>
    <h5 class="text-center">The Sandcoin wallet uses a different config directory than the existing Casinocoin wallet<br />
        Both wallets can run simultaneously and independently on the same host<br />
        Wallets can be freely imported between both versions of the wallet<br />
        You can send coins freely from either wallet type to each other<br />
        Sandcoins can be sent to any exchange that currently trades Casinocoins<br />
        Sandcoins will have it's own website located at: http://sandcoins.com/<br />
        Casinocoin wallets and Sandcoin wallets operate on the same chain<br />
        The Sandcoin wallet will track the same Casinocoin version numbers</h5>
</section>



</div>