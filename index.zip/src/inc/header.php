<?php
/**
 * Created by PhpStorm.
 * User: kepoly
 * Date: 2/24/2016
 * Time: 7:24 PM
 */
?>
<!DOCTYPE html>
<html ng-app="myApp">
<head>
    <base href="<?php echo WEBSITE_PATH ?>#/">
    <meta Name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" type="text/css" href="<?php echo WEBSITE_PATH ?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEBSITE_PATH ?>assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="<?php echo WEBSITE_PATH ?>assets/css/font.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../bower_components/html5shiv/dist/html5shiv.js"></script>
    <script src="../bower_components/respond/dest/respond.min.js"></script>
    <![endif]-->

</head>
<body>
