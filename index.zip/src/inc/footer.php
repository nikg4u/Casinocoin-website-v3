<?php
/**
 * Created by PhpStorm.
 * User: kepoly
 * Date: 2/24/2016
 * Time: 7:24 PM
 */
?>
<footer class="footer">

    <div class="col-md-4">

    </div>
    <div class="col-md-4 middleFooter">
       <a href="https://www.facebook.com/CasinoCoinNews" target="_blank"><i class="fa fa-facebook"></i></a>
       <a href="https://twitter.com/CasinocoinNews" target="_blank"><i class="fa fa-twitter"></i></a>
       <a href="https://bitcointalk.org/index.php?topic=616792.0" target="_blank"><i class="fa fa-bitcoin"></i></a>
       <a href="https://www.reddit.com/r/casinocoin" target="_blank"> <i class="fa fa-reddit"></i></a>
       <a href="slack" target="_blank"><i class="fa fa-slack"></i></a>


    </div>
    <div class="col-md-4">

    </div>

</footer>
<div class="secondFooter">
    <h3>CasinoCoin 2016</h3>
</div>
<script src="<?php echo WEBSITE_PATH ?>assets/js/angular.js"></script>
<script src="<?php echo WEBSITE_PATH ?>assets/js/angular-resource.js"></script>
<script src="<?php echo WEBSITE_PATH ?>assets/js/angular-route.js"></script>
<script src="<?php echo WEBSITE_PATH ?>assets/js/angular-ui.js"></script>
<script src="<?php echo WEBSITE_PATH ?>/assets/js/app.js"></script>
<script src="<?php echo WEBSITE_PATH ?>assets/js/jquery.js"></script>
<script src="<?php echo WEBSITE_PATH ?>assets/js/boot.js"></script>
<script type="text/javascript">


    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-41851204-17', 'casinocoin.org');
    ga('send', 'pageview');


</script>
</body>
</html>